import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Cube from './Components/Cube'
import api from './BaseClass';
import './App.css'

const App = () => {
    const [cubes, setCubes] = useState([]);
    const [formData, setFormData] = useState({ width: '', length: '', height: '' });
    const [editMode, setEditMode] = useState(false);
    const [editId, setEditId] = useState(null);

    useEffect(() => {
        fetchCubes();
    }, []);

    const fetchCubes = () => {
        api.get('/cube')
            .then(response => setCubes(response.data))
            .catch(error => console.error(error));
    };

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        if (editMode) {
            api.put(`/cube/${editId}`, formData)
                .then(() => {
                    fetchCubes();
                    setEditMode(false);
                    setEditId(null);
                    setFormData({ width: '', length: '', height: '' });
                })
                .catch(error => console.error(error));
        } else {
            api.post('/cube', formData)
                .then(() => {
                    fetchCubes();
                    setFormData({ width: '', length: '', height: '' });
                })
                .catch(error => console.error(error));
        }
    };

    const handleEdit = (id) => {
        const cube = cubes.find(cube => cube.id === id);
        setFormData({ width: cube.width, length: cube.length, height: cube.height, id: cube.id });
        setEditMode(true);
        setEditId(id);
    };

    const handleDelete = (id) => {
        api.delete(`/cube/${id}`)
            .then(() => fetchCubes())
            .catch(error => console.error(error));
    };

    return (
        <div>
            <Cube />
            <div className='main-container'>
                <div className='left-panel'>
                    <h1>3D Cube Application</h1>

                    <form className="cube-form" onSubmit={handleSubmit}>

                        <div className="form-group">
                            <label htmlFor="height">Height:</label>
                            <input type="number" name="height" value={formData.height} onChange={handleInputChange} required />
                        </div>
                        <div className="form-group">
                            <label htmlFor="width">Width:</label>
                            <input type="number" name="width" value={formData.width} onChange={handleInputChange} required />
                        </div>
                        <div className="form-group">
                            <label htmlFor="length">Length:</label>
                            <input type="number" name="length" value={formData.length} onChange={handleInputChange} required />
                        </div>
                        <button className = 'Submit' type="submit">{editMode ? 'Update' : 'Create'}</button>

                    </form>
                </div>
                <div className='right-panel'>
                    <h1>Cube List</h1>
                    <table className="cube-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Height</th>
                                <th>Width</th>
                                <th>Length</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cubes.map((cube) => (
                                <tr key={cube.id}>
                                    <td>{cube.id}</td>
                                    <td>{cube.height}</td>
                                    <td>{cube.width}</td>
                                    <td>{cube.length}</td>
                                    <div className='button-container'>
                                    <button className='Actionbutton' onClick={() => handleEdit(cube.id)}>Edit</button>
                                    <button className='Actionbutton' onClick={() => handleDelete(cube.id)}>Delete</button>
                                    </div>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    );
};

export default App;